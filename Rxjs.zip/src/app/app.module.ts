import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { Demo1Component } from './demo1/index.component';

// 定义路由对象
const appRoutes: Routes = [
  { path: '', component: AppComponent },
  { path: 'demo1', component: Demo1Component },
];

@NgModule({
  // 组件声明;
  declarations: [
    AppComponent,
    Demo1Component,
  ],
  // imports数组中应该只有NgModule类。不要放置其它类型的类。
  imports: [
    BrowserModule,
    // 路由规则的定义 -- RouterModule.forRoot方法
    RouterModule.forRoot(
      appRoutes,
    ),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
